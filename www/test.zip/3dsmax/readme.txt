3 tga format rendering images stored at \previews folder
scene file stored in \scenes folder named cheungsiusin_Assignment01.max
all of the textures stored inside \sceneassets\images